package com.example.ac2;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CADASTRO = 1;
    private static final int REQUEST_NOTIFICATION_PERMISSION = 100;
    public static final String CHANNEL_ID = "treino_channel";

    private TextView tvExercicioAtual, tvTimer;
    private Button btnIniciarTreino, btnCadastrar;
    private ListView listaExercicios;

    private List<Exercicio> lista;
    private ArrayAdapter<Exercicio> adapter;

    private CountDownTimer timer;
    private int currentExerciseIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvExercicioAtual = findViewById(R.id.tv_exercicioAtual);
        tvTimer = findViewById(R.id.tv_timer);
        btnIniciarTreino = findViewById(R.id.btn_iniciarTreino);
        btnCadastrar = findViewById(R.id.btn_cadastrar);
        listaExercicios = findViewById(R.id.lista_exercicios);

        lista = new ArrayList<>();
        lista.add(new Exercicio("Agachamento", 30));
        lista.add(new Exercicio("Flexão", 20));
        lista.add(new Exercicio("Descanso", 10));

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista);
        listaExercicios.setAdapter(adapter);

        criarCanalNotificacao();
        solicitarPermissaoNotificacao();

        btnIniciarTreino.setOnClickListener(v -> iniciarTreino());

        btnCadastrar.setOnClickListener(v -> {
            Intent intent = new Intent(this, CadastroActivity.class);
            startActivityForResult(intent, REQUEST_CADASTRO);
        });
    }

    private void solicitarPermissaoNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQUEST_NOTIFICATION_PERMISSION);
            }
        }
    }

    private void criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel canal = new NotificationChannel(
                    CHANNEL_ID,
                    "Canal do Treino",
                    NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(canal);
            }
        }
    }

    private void iniciarTreino() {
        if (lista.isEmpty()) {
            Toast.makeText(this, "Nenhum exercício cadastrado!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (timer != null) timer.cancel();

        currentExerciseIndex = 0;
        proximoExercicio();
    }

    private void proximoExercicio() {
        if (currentExerciseIndex >= lista.size()) {
            notificar("Treino concluído!", "Parabéns! Você terminou o treino.");
            tvExercicioAtual.setText("Concluído!");
            tvTimer.setText("0s");
            return;
        }

        Exercicio exercicioAtual = lista.get(currentExerciseIndex);
        tvExercicioAtual.setText(exercicioAtual.getNome());
        tvTimer.setText(exercicioAtual.getDuracao() + "s");

        notificar("Exercício: " + exercicioAtual.getNome(), "Prepare-se para " + exercicioAtual.getDuracao() + " segundos!");

        timer = new CountDownTimer(exercicioAtual.getDuracao() * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                tvTimer.setText((millisUntilFinished / 1000) + "s");
            }

            @Override
            public void onFinish() {
                currentExerciseIndex++;
                proximoExercicio();
            }
        }.start();
    }

    private void notificar(String titulo, String mensagem) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle(titulo)
                .setContentText(mensagem)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify((int) System.currentTimeMillis(), builder.build());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CADASTRO && resultCode == RESULT_OK && data != null) {
            String nome = data.getStringExtra("nome");
            int duracao = data.getIntExtra("duracao", 0);

            if (nome != null && duracao > 0) {
                lista.add(new Exercicio(nome, duracao));
                adapter.notifyDataSetChanged();
            }
        }
    }
}




