package com.example.ac2;

public class Exercicio {
    private String nome;
    private int duracao; // em segundos

    public Exercicio(String nome, int duracao) {
        this.nome = nome;
        this.duracao = duracao;
    }

    public String getNome() {
        return nome;
    }

    public int getDuracao() {
        return duracao;
    }

    @Override
    public String toString() {
        return nome + " – " + duracao + "s";
    }
}


