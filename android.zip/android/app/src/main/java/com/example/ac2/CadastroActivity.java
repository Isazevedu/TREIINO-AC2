package com.example.ac2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    private EditText etNome, etDuracao;
    private Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        etNome = findViewById(R.id.et_nomeExercicio);
        etDuracao = findViewById(R.id.et_duracaoExercicio);
        btnSalvar = findViewById(R.id.btn_salvar);

        btnSalvar.setOnClickListener(v -> {
            String nome = etNome.getText().toString().trim();
            String duracaoStr = etDuracao.getText().toString().trim();

            if (nome.isEmpty() || duracaoStr.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            int duracao = Integer.parseInt(duracaoStr);
            Exercicio novo = new Exercicio(nome, duracao);

            Intent resultado = new Intent();
            resultado.putExtra("nome", novo.getNome());
            resultado.putExtra("duracao", novo.getDuracao());
            setResult(RESULT_OK, resultado);
            finish();
        });
    }
}

